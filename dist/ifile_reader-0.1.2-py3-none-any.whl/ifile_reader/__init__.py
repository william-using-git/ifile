from ifile_reader.api.ifile import IFile

__all__ = ["IFile"]