from ifile_reader.api.ifile import IFile
